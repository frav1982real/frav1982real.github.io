# -*- coding: utf-8 -*-
"""
Addon Tutorial Kodi — Passo 2/3: le fondamenta della tua idea.

Le 4 basi implementate:
  1. PVR IPTV Simple Client     -> lib/pvr.py + route /pvrupdate
     l'addon genera la playlist M3U, la scrive in userdata, punta il PVR
     a quel file e lo ricarica. I canali compaiono nella sezione TV di Kodi.

  2. Resolving sul momento (PPV) -> lib/resolver.py + route /play/<id>
     i PPV NON hanno link salvati: al click Kodi richiama l'addon e il link
     nasce in quel momento (aggancio per la tua logica skyppv).

  3. Link esistenti (canali free) -> lib/channels.py
     i canali free leggono l'URL già noto da resources/canali.json
     (riempito da tools/free_links.json: i link che hai già).

  4. Rispetto dell'LCN -> lib/playlist.py e menu /channels
     l'LCN del JSON diventa tvg-chno nella playlist (numerazione guida TV)
     e compare nell'etichetta della lista canali.

Fasi del plugin (come in ogni addon):
  FASE ELENCO : Kodi chiama "/" o "/channels" -> si costruisce il menu
  FASE PLAY   : Kodi chiama "/play/<id>"      -> si risolve e si riproduce
"""

import routing
import xbmcgui
import xbmcplugin

from lib import channels, playlist, resolver

plugin = routing.Plugin()


# ============================================================================
# MENU PRINCIPALE
# ============================================================================
@plugin.route("/")
def index():
    handle = plugin.handle

    # 1) Aggiorna la lista nel PVR IPTV Simple Client
    li = xbmcgui.ListItem(label="Aggiorna lista PVR (IPTV Simple Client)")
    xbmcplugin.addDirectoryItem(handle, plugin.url_for(pvrupdate), li, isFolder=False)

    # 2) Sfoglia i canali dentro l'addon (utile per testare senza PVR)
    li = xbmcgui.ListItem(label="Sfoglia canali")
    xbmcplugin.addDirectoryItem(handle, plugin.url_for(channels_route), li, isFolder=True)

    xbmcplugin.endOfDirectory(handle, succeeded=True)


# ============================================================================
# INTEGRAZIONE PVR IPTV SIMPLE CLIENT
# ============================================================================
@plugin.route("/pvrupdate")
def pvrupdate():
    # 1. il PVR deve essere installato
    from lib import pvr
    if not pvr.pvr_installed():
        xbmcgui.Dialog().notification(
            "CanàTV Plus", "Installa il PVR IPTV Simple Client dal repository",
            xbmcgui.NOTIFICATION_ERROR, 8000)
        return

    # 2. genera la playlist dal JSON (LCN rispettati: tvg-chno)
    canali = channels.by_file_order()
    content = playlist.build_playlist(canali)

    # 3. scrivi il file e punta il PVR
    path = pvr.write_playlist(content)
    pvr.set_pvr_settings(path)

    # 4. ricarica il PVR (disattiva -> pulisci cache -> riattiva)
    pvr.reload_pvr()

    xbmcgui.Dialog().notification(
        "CanàTV Plus", f"Lista aggiornata: {len(canali)} canali", 5000)


# ============================================================================
# SFOGLIA CANALI (dentro l'addon — stesso contenuto della lista PVR)
# ============================================================================
@plugin.route("/channels")
def channels_route():
    handle = plugin.handle
    canali = channels.by_file_order()

    for c in canali:
        # etichetta con LCN: "[108] Sky Uno HD"
        li = xbmcgui.ListItem(label=f"[{c['lcn']}] {c['name']}")
        li.setInfo("video", {"title": c["name"]})
        li.setProperty("IsPlayable", "true")       # Kodi 21: item riproducibile

        # link diretto se c'è, altrimenti l'addon risolverà al click
        if c["type"] == "free" and c.get("url"):
            url = c["url"]
        else:
            url = plugin.url_for(play, c["id"])

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True)


# ============================================================================
# RIPRODUZIONE — resolving sul momento
# ============================================================================
@plugin.route("/play/<channel_id>")
def play(channel_id):
    handle = plugin.handle

    ch = channels.get_channel(channel_id)
    if ch is None:
        _resolve_failed(f"Canale sconosciuto: {channel_id}")
        return

    # qui, adesso, si ricava l'URL
    result = resolver.resolve(ch)

    if not result or not result.get("url"):
        _resolve_failed(f"Link non disponibile per {ch['name']}")
        return

    # costruisci l'item da riprodurre
    li = xbmcgui.ListItem(path=result["url"])
    li.setInfo("video", {"title": ch["name"]})

    # DRM (es. ClearKey degli Sky PPV) → inputstream.adaptive
    if result.get("drm"):
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setProperty("inputstream.adaptive.license_type",
                       result.get("drm_type", ""))
        li.setProperty("inputstream.adaptive.license_key",
                       result.get("drm_key", ""))

    xbmcplugin.setResolvedUrl(handle, True, li)


def _resolve_failed(msg):
    xbmcgui.Dialog().notification("Tutorial Kodi", msg,
                                  xbmcgui.NOTIFICATION_ERROR, 8000)
    # comunica a Kodi che la risoluzione è fallita (evita spinner infinito)
    xbmcplugin.setResolvedUrl(plugin.handle, False, xbmcgui.ListItem())


if __name__ == "__main__":
    plugin.run()
