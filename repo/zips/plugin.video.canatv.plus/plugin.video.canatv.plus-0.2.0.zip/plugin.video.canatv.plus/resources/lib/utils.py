import logging
import base64

# User-Agent per l'endpoint Heroku dei PPV (Sky)
SKY_UA = "okhttp/4.11.0"


def log(msg):
    text = "[CANATTV] %s" % msg
    try:
        import xbmc
        xbmc.log(text, xbmc.LOGINFO)
    except Exception:
        try:
            logging.info(text)
        except Exception:
            pass

def _xor_decrypt(data_b64, key):
    data = base64.b64decode(data_b64)
    key_bytes = (key or "").encode()
    if not key_bytes:
        return ""
    out = bytearray()
    for i, byte in enumerate(data):
        out.append(byte ^ key_bytes[i % len(key_bytes)])
    return out.decode("utf-8")
