#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generatore di resources/canali.json per l'addon.

Prende in ingresso:
  1. canali.json        -> la lista canali (LCN, nome, id) — i tuoi 195 canali
  2. tools/ppv_ids.json -> gli id dei canali PPV (generati da skyppv.py)
  3. tools/free_links.json -> MAPPA id -> url dei canali FREE (la riempi tu
                          con i link esistenti che hai già)

E produce:
  plugin.video.tutorial/resources/canali.json  -> con campi aggiunti:
      type   = "ppv" | "free"      (come si ottiene il link)
      group  = sezione del canale  (per la guida TV del PVR)
      url    = link esistente      (solo per i free; "" se non ancora noto)

Uso:
  python3 tools/build_canali.py                 # usa i default in cartella
  python3 tools/build_canali.py --free free_links.json
"""

import argparse
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CANALI = os.path.join(HERE, "..", "data", "canali.json")          # i tuoi 195 canali
DEFAULT_PPV = os.path.join(HERE, "..", "data", "ppv_ids.json")
DEFAULT_FREE = os.path.join(HERE, "..", "data", "free_links.json")
OUTPUT = os.path.join(HERE, "..", "..", "plugin.video.canatv.plus", "resources", "data", "canali.json")

# Sezione (gruppo guida TV) in base al LCN, come nel documento Sky.
def group_for_lcn(lcn):
    if lcn < 200:            return "Intrattenimento e Serie TV"
    if lcn < 249:            return "Sport"
    if lcn < 300:            return "Calcio"
    if lcn < 400:            return "Cinema"
    if lcn < 600:            return "News"
    if lcn < 700:            return "Bambini"
    if lcn < 800:            return "Primafila"
    if lcn >= 1000:          return "Regionali"
    return "Canali"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--canali", default=DEFAULT_CANALI)
    ap.add_argument("--ppv", default=DEFAULT_PPV)
    ap.add_argument("--free", default=DEFAULT_FREE)
    args = ap.parse_args()

    canali = json.load(open(args.canali, encoding="utf-8"))["channels"]
    ppv_ids = set(json.load(open(args.ppv, encoding="utf-8")))

    free_links = {}
    if os.path.isfile(args.free):
        free_links = json.load(open(args.free, encoding="utf-8"))

    out = []
    for c in canali:
        cid = c["id"]
        # 1) esplicito in ppv_ids.json  -> PPV
        # 2) PrimaFila (Sky)             -> PPV (i nomi del decoder non
        #                                   coincidono sempre con skyppv.py)
        if cid in ppv_ids or cid.startswith("skyprimafila"):
            ctype = "ppv"
        else:
            ctype = "free"

        out.append({
            "lcn": c["lcn"],
            "name": c["name"],
            "id": cid,
            "type": ctype,
            "group": group_for_lcn(c["lcn"]),
            "url": free_links.get(cid, ""),   # link esistente, se lo hai
        })

    os.makedirs(os.path.dirname(OUTPUT), exist_ok=True)
    with open(OUTPUT, "w", encoding="utf-8") as f:
        json.dump({"channels": out}, f, ensure_ascii=False, indent=1)

    n_ppv = sum(1 for x in out if x["type"] == "ppv")
    n_free = len(out) - n_ppv
    n_free_no_link = sum(1 for x in out if x["type"] == "free" and not x["url"])
    print(f"Scritto {OUTPUT}")
    print(f"  totale : {len(out)}")
    print(f"  PPV    : {n_ppv}   (risolti al momento del click)")
    print(f"  free   : {n_free}  (di cui {n_free_no_link} senza link: riempi tools/free_links.json)")


if __name__ == "__main__":
    main()
