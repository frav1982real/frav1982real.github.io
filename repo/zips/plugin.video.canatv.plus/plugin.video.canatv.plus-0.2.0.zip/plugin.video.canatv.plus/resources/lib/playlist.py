# -*- coding: utf-8 -*-
"""
Generazione della playlist M3U per il PVR IPTV Simple Client.

Il file che il PVR legge ha un canale per blocco di due righe:

    #EXTINF:-1 tvg-id="skyunohd" tvg-chno="108" tvg-name="Sky Uno HD" group-title="...",Sky Uno HD
    <url di riproduzione>

<url di riproduzione> può essere:
  - un URL diretto (canale free con link esistente) -> il PVR/Kodi lo riproduce
  - una URL plugin://.../play/<id> (PPV)            -> al click Kodi richiama
    l'addon, che risolve il link IN QUEL MOMENTO

tvg-chno = LCN: è così che il PVR mostra la numerazione giusta nella guida TV.
"""

# ID dell'addon usato per costruire le URL plugin:// (va cambiato se rinomini l'addon)
ADDON_ID = "plugin.video.canatv.plus"


def build_playlist(channels):
    """Costruisce il testo della playlist M3U a partire dalla lista canali."""
    lines = ["#EXTM3U"]

    for c in channels:
        header = (
            f'#EXTINF:-1 tvg-id="{c["id"]}" '
            f'tvg-chno="{c["lcn"]}" '
            f'tvg-name="{c["name"]}" '
            f'group-title="{c.get("group", "")}",{c["name"]}'
        )
        lines.append(header)

        # free con link esistente -> URL diretto nella playlist
        if c["type"] == "free" and c.get("url"):
            lines.append(c["url"])
        # tutto il resto (PPV, free senza link) -> l'addon decide al click
        else:
            lines.append(f"plugin://{ADDON_ID}/play/{c['id']}")

    return "\n".join(lines) + "\n"
