# -*- coding: utf-8 -*-
"""Entrypoint di plugin.video.canatv.plus.

Minimale, come raccomandato dalla documentazione Kodi: tutta la logica
sta in resources/lib/.
"""

from resources.lib import router


if __name__ == "__main__":
    router.run()
