# -*- coding: utf-8 -*-
"""Metodo di resolving WorldLiveTV: stream ufficiali risolti AL MOMENTO
del play, con un "broadcaster" per editore:

  - rai        -> raiplay.it/dirette.json + relinker (output=63)
  - mediaset   -> flussi HLS/DASH clear Tundrak/IPTV-Italia (ch-<slug>-clr)
  - la7        -> URL CDN note + scrape firmato della pagina la7.it
  - discovery  -> API Aurora (public.aurora.enhanced.live) con token guest
  - sky (free) -> API player video.sky.it (Sky TG24, Cielo, TV8)

Ogni resolver verifica che il manifest sia vivo (_first_reachable) prima di
restituirlo; se nessuno funziona si torna None e resolver.py passa al
fallback Vavoo.
"""
import base64
import re

import requests

from . import utils

BROWSER_HEADERS = {
    "User-Agent": utils.SKY_UA,
    "Accept": "*/*",
    "Accept-Language": "it-IT,it;q=0.9,en;q=0.8",
}

RAI_BY_ID = {
    "rai1": "Rai 1",
    "rai2": "Rai 2",
    "rai3": "Rai 3",
    "rai4": "Rai 4",
    "rai5": "Rai 5",
    "raimovie": "Rai Movie",
    "raipremium": "Rai Premium",
    "raigulp": "Rai Gulp",
    "raiyoyo": "Rai Yoyo",
    "rainews24": "Rai News 24",
    "raistoria": "Rai Storia",
    "raiscuola": "Rai Scuola",
    "raisport": "Rai Sport",
    "rai4k": "Rai 4K",
}

MEDIASET_CALLSIGNS = {
    "rete4": "R4",
    "canale5": "C5",
    "italia1": "I1",
    "20mediaset": "LB",
    "iris": "KI",
    "la5": "KA",
    "italia2": "I2",
    "mediasetitalia2": "I2",
    "mediasetextra": "KQ",
    "cine34": "B6",
    "topcrime": "LT",
    "tgcom24": "KF",
    "twentyseven": "TS",
    "27twentyseven": "TS",
    "focus": "FU",
    "boing": "KB",
    "cartoonito": "LA",
}
HBBTV_UA = "HbbTV/1.6.1"

# Stream ufficiali clear (no DRM) da Tundrak/IPTV-Italia
MEDIASET_CLR = {
    "C5": "c5", "I1": "i1", "R4": "r4", "LB": "lb", "KI": "ki",
    "KA": "ka", "I2": "i2", "KQ": "kq", "B6": "b6", "LT": "lt",
    "KF": "kf", "TS": "ts", "FU": "fu", "KB": "kb", "LA": "la",
}

# Playlist ufficiali La7 (stabili, no token)
LA7_CLEAR = "https://d3749synfikwkv.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/cc-74ylxpgd78bpb/Live.m3u8"
LA7_CLEAR_ALT = "https://d15umi5iaezxgx.cloudfront.net/LA7/CLN/HLS/Live.m3u8"
LA7_CLEAR_AKAMAI = "https://live-la7-lh.akamaihd.net/i/LA7_1@199280/master.m3u8"
LA7_CLEAR_AKAMAI_ALT = "https://live-la7-lh.akamaihd.net/i/LA7_1@199280/index_3000_av-p.m3u8"
LA7D_CLEAR = "https://d15umi5iaezxgx.cloudfront.net/LA7D/CLN/HLS/Live.m3u8"
LA7D_CLEAR_AKAMAI = "https://live-la7-lh.akamaihd.net/i/LA7_2@199281/index_3000_av-p.m3u8"

DISCOVERY_HOSTS = {
    "Nove": {"id": 3, "code": "nove", "host": "nove.tv"},
    "Real Time": {"id": 2, "code": "realtime", "host": "realtime.it"},
    "DMAX": {"id": 4, "code": "dmaxit", "host": "dmax.it"},
    "Giallo": {"id": 27, "code": "giallo", "host": "giallotv.it"},
    "Food Network": {"id": 6, "code": "foodnetwork", "host": "foodnetwork.it"},
    "K2": {"id": 24, "code": "k2", "host": "k2tv.it"},
    "Frisbee": {"id": 26, "code": "frisbee", "host": "frisbeetv.it"},
}


def _get(url, **kwargs):
    headers = dict(BROWSER_HEADERS)
    headers.update(kwargs.pop("headers", {}) or {})
    return requests.get(url, headers=headers, timeout=kwargs.pop("timeout", 20), **kwargs)


# --------------------------------------------------------------------------
# Riconoscimento broadcaster
# --------------------------------------------------------------------------

def infer_play_ref(ch):
    """Dato un canale (dict) ritorna il play_ref WLTV ("rai:...", ...) o "". """
    wid = (ch.get("wltv_id") or "").lower()
    name = ch.get("name") or ""
    norm = utils.normalize_name(name)

    if wid in RAI_BY_ID or norm.startswith("RAI"):
        return "rai:%s" % (RAI_BY_ID.get(wid) or name)
    if wid in MEDIASET_CALLSIGNS:
        return "mediaset:$%s" % MEDIASET_CALLSIGNS[wid]
    cs = _mediaset_callsign(name)
    if cs in MEDIASET_CLR:
        return "mediaset:$%s" % cs
    if wid == "la7" or norm in ("LA7", "LA7HD"):
        return "la7:La7"
    if wid in ("la7d", "la7cinema") or norm in ("LA7D", "LA7CINEMA"):
        return "la7:La7d"
    for disc_name in DISCOVERY_HOSTS:
        if norm == utils.normalize_name(disc_name):
            return "discovery:%s" % name
    # canali Sky gratuiti (TG24/Cielo/TV8)
    if norm in ("SKYTG24", "CIELO", "TV8"):
        return "sky:%s" % name
    return ""


def _unwrap_identifier(ref):
    """Converte URL WLTV helper / HTTP scaduti in un play_ref stabile."""
    ref = (ref or "").strip()
    if ref.startswith("plugin://plugin.video.wltvhelper/play/"):
        rest = ref.split("/play/", 1)[1]
        parts = rest.split("/", 1)
        if len(parts) == 2:
            return "%s:%s" % (parts[0], requests.utils.unquote(parts[1]))
        return rest
    return ref


# --------------------------------------------------------------------------
# Broadcaster: RAI
# --------------------------------------------------------------------------

def _resolve_rai(search):
    search = RAI_BY_ID.get(re.sub(r"[^a-z0-9]+", "", (search or "").lower()), search)
    data = _get("https://www.raiplay.it/dirette.json").json()
    target = utils.normalize_name(search)
    relinker = ""
    for channel in data.get("contents") or []:
        name = channel.get("channel") or ""
        if utils.normalize_name(name) == target or target.startswith(utils.normalize_name(name)):
            relinker = ((channel.get("video") or {}).get("content_url") or "")
            break
    if not relinker:
        return None
    joined = relinker + ("&" if "?" in relinker else "?") + "output=63&forceUserAgent=raiplayappletv"
    payload = _get(joined).json()
    videos = payload.get("video") or []
    url = videos[0] if videos else ""
    if not url or "video_no_available" in url:
        joined = relinker + ("&" if "?" in relinker else "?") + "output=63&forceUserAgent=raiplayhbbtv"
        payload = _get(joined).json()
        videos = payload.get("video") or []
        url = videos[0] if videos else ""
    if not url or "video_no_available" in url:
        return None
    return {"url": url, "drm": False, "user_agent": utils.SKY_UA}


# --------------------------------------------------------------------------
# Broadcaster: Mediaset (flussi clear Tundrak/IPTV-Italia)
# --------------------------------------------------------------------------

def _mediaset_callsign(search):
    raw = (search or "").strip()
    if raw.startswith("$"):
        return raw[1:].upper()
    compact = re.sub(r"[^a-z0-9]+", "", raw.lower())
    if compact in MEDIASET_CALLSIGNS:
        return MEDIASET_CALLSIGNS[compact]
    wanted = utils.normalize_name(raw)
    for name, code in (
        ("Canale 5", "C5"), ("Italia 1", "I1"), ("Rete 4", "R4"),
        ("20 Mediaset", "LB"), ("Iris", "KI"), ("La 5", "KA"),
        ("Italia 2", "I2"), ("Mediaset Extra", "KQ"), ("Cine 34", "B6"),
        ("Top Crime", "LT"), ("TgCom 24", "KF"), ("Twentyseven", "TS"),
        ("Focus", "FU"), ("Boing", "KB"), ("Cartoonito", "LA"),
    ):
        if utils.normalize_name(name) == wanted:
            return code
    return raw.upper()[:4]


def _first_reachable(urls, headers, timeout=8):
    """Primo URL che risponde 200 con manifesto HLS/DASH. Se tutti 403 (geo) torna il primo."""
    first = ""
    for url in urls:
        if not url:
            continue
        if not first:
            first = url
        try:
            resp = requests.get(url, headers=headers, timeout=timeout, stream=True, allow_redirects=True)
            status = resp.status_code
            chunk = b""
            try:
                chunk = next(resp.iter_content(640), b"")
            except Exception:
                pass
            try:
                resp.close()
            except Exception:
                pass
            text = chunk.decode("utf-8", "ignore")
            ok = status == 200 and (
                "#EXTM3U" in text or "<MPD" in text or "<?xml" in text or "SmoothStreaming" in text
            )
            utils.log("probe %s -> HTTP %s ok=%s" % (url[:90], status, ok))
            if ok:
                return url
        except Exception as exc:
            utils.log("probe fail %s: %s" % (url[:90], exc))
    return first


def _resolve_mediaset(search):
    """Flussi HLS/DASH clear Mediaset (Tundrak/IPTV-Italia), niente Widevine."""
    callsign = _mediaset_callsign(search)
    slug = MEDIASET_CLR.get(callsign) or MEDIASET_CLR.get(callsign.upper())
    if not slug:
        slug = (callsign or "").lower()
    # HLS prima: i MPD clr vanno in loop su Kodi.
    urls = [
        "https://live02-seg.msf.cdn.mediaset.net/live/ch-%s/%s-clr.isml/index.m3u8" % (slug, slug),
        "https://live03-col.msf.cdn.mediaset.net/live/ch-%s/%s-clr.isml/index.m3u8" % (slug, slug),
        "https://live2.msf.cdn.mediaset.net/content/hls_h0_clr_vos/live/channel(%s)/index.m3u8" % slug,
        "https://live03-col.msf.cdn.mediaset.net/live/ch-%s/%s-clr.isml/manifest.mpd" % (slug, slug),
    ]
    headers = {
        "User-Agent": HBBTV_UA,
        "Referer": "https://www.mediasetplay.mediaset.it/",
        "Origin": "https://www.mediasetplay.mediaset.it",
        "Accept": "*/*",
    }
    url = _first_reachable(urls, headers)
    utils.log("Mediaset %s/%s -> %s" % (callsign, slug, (url or "")[:90]))
    return {
        "url": url,
        "drm": False,
        "use_isa": True,
        "user_agent": HBBTV_UA,
        "referer": "https://www.mediasetplay.mediaset.it/",
    }


# --------------------------------------------------------------------------
# Broadcaster: La7 / La7d
# --------------------------------------------------------------------------

def _scrape_la7_clear(search):
    path = "/live-la7d" if "7d" in (search or "").lower().replace(" ", "") else "/dirette-tv"
    try:
        html = _get("https://www.la7.it" + path).text
    except Exception as exc:
        utils.log("La7 scrape pagina: %s" % exc)
        return ""
    url = ""
    match = re.search(r'var la7cln\s*=\s*"([^"]+)"', html)
    if match:
        url = match.group(1)
    if not url:
        match = re.search(r'var l7cln\s*=\s*"([^"]+)"', html)
        if match:
            try:
                url = base64.b64decode(match.group(1)).decode("utf-8")
            except Exception:
                url = ""
    if not url:
        match = re.search("""["']?hls["']?\\s*:\\s*["']([^"']+)["']""", html)
        if match and "DRM" not in match.group(1).upper():
            url = match.group(1)
    if url and "DRM" in url.upper():
        return ""
    return url


def _resolve_la7(search):
    """HLS in chiaro: URL CDN, IPTV-Italia, Akamai, scrape firmato."""
    is_la7d = "7d" in (search or "").lower().replace(" ", "")
    if is_la7d:
        candidates = [LA7D_CLEAR, LA7D_CLEAR_AKAMAI]
    else:
        candidates = [LA7_CLEAR, LA7_CLEAR_ALT, LA7_CLEAR_AKAMAI, LA7_CLEAR_AKAMAI_ALT]
    scraped = _scrape_la7_clear(search)
    if scraped:
        candidates.append(scraped)
    headers = {
        "User-Agent": utils.SKY_UA,
        "Referer": "https://www.la7.it/dirette-tv",
        "Origin": "https://www.la7.it",
        "Accept": "*/*",
    }
    url = _first_reachable(candidates, headers)
    if not url:
        utils.log("La7: nessuno stream clear (fallback Vavoo)")
        return None
    utils.log("La7 scelta: %s" % url[:100])
    return {
        "url": url,
        "drm": False,
        "use_isa": True,
        "user_agent": utils.SKY_UA,
        "referer": "https://www.la7.it/dirette-tv",
    }


# --------------------------------------------------------------------------
# Broadcaster: Discovery / WBD (Nove, Real Time, DMAX, Giallo, Food, K2, Frisbee)
# --------------------------------------------------------------------------

def _resolve_discovery(search):
    cfg = None
    for name, data in DISCOVERY_HOSTS.items():
        if utils.normalize_name(name) == utils.normalize_name(search):
            cfg = data
            break
    if not cfg:
        return None
    headers = dict(BROWSER_HEADERS)
    headers["Referer"] = "https://%s/" % cfg["host"]
    headers["Origin"] = "https://%s" % cfg["host"]
    cfg_url = (
        "https://public.aurora.enhanced.live/site/configurations"
        "?include=default&filter[environment]=%s&v=2" % cfg["code"]
    )
    try:
        site = _get(cfg_url, headers=headers).json()
        simulcast = site["settings"]["site"]["simulcast"]
        base = simulcast["sonicEndpoint"]
        realm = simulcast["sonicRealm"]
    except Exception:
        base = "https://public.aurora.enhanced.live"
        realm = "it"
    headers["X-Device-Info"] = "STONEJS/1 (Unknown/Unknown; Windows/NT 10.0; Unknown)"
    headers["X-disco-params"] = "realm=it"
    headers["X-disco-client"] = "WEB:UNKNOWN:wbdatv:2.1.9"
    token = _get("%s/token?realm=%s" % (base, realm), headers=headers).json()["data"]["attributes"]["token"]
    headers["Authorization"] = "Bearer %s" % token
    headers["Content-Type"] = "application/json"
    body = (
        '{"deviceInfo":{"adBlocker":false,"drmSupported":false,"hdrCapabilities":["SDR"],'
        '"hwDecodingCapabilities":[],"soundCapabilities":["STEREO"]},'
        '"wisteriaProperties":{"platform":"desktop"},"channelId":"%s"}' % cfg["id"]
    )
    data = requests.post(
        "%s/playback/v3/channelPlaybackInfo" % base,
        headers=headers,
        data=body,
        timeout=20,
    ).json()
    streams = (((data.get("data") or {}).get("attributes") or {}).get("streaming")) or []
    url = ""
    for stream in streams:
        if stream.get("type") == "hls" and stream.get("url"):
            url = stream["url"]
            break
    if not url and streams:
        url = streams[0].get("url") or ""
    if not url:
        return None
    return {"url": url, "drm": False, "user_agent": utils.SKY_UA, "headers": headers}


# --------------------------------------------------------------------------
# Broadcaster: Sky free (Sky TG24, Cielo, TV8)
# --------------------------------------------------------------------------

def _probe_manifest(url, user_agent=None, referer=None, origin=None, timeout=8):
    """True se l'URL risponde 200 con un manifesto HLS/DASH valido."""
    headers = {"User-Agent": user_agent or utils.SKY_UA, "Accept": "*/*"}
    if referer:
        headers["Referer"] = referer
    if origin:
        headers["Origin"] = origin
    try:
        resp = requests.get(url, headers=headers, timeout=timeout, stream=True, allow_redirects=True)
        try:
            status = resp.status_code
            chunk = next(resp.iter_content(256), b"")
        finally:
            try:
                resp.close()
            except Exception:
                pass
        if status != 200:
            return False
        text = chunk.decode("utf-8", "ignore").lstrip()
        return any(text.startswith(p) for p in ("#EXTM3U", "<?xml", "<MPD"))
    except Exception:
        return False


def _resolve_sky_free(sky_id):
    """Risolve TV8 / Cielo / Sky TG24 via API player Sky."""
    if not sky_id:
        return None
    sky_id = str(sky_id)
    referer = utils.SKY_FREE_REFERER.get(sky_id, "https://video.sky.it/")
    headers = {
        "User-Agent": utils.SKY_UA,
        "Accept": "application/json",
        "Referer": referer,
        "Origin": "https://video.sky.it",
    }
    try:
        resp = requests.get(utils.SKY_FREE_API.format(sky_id), headers=headers, timeout=15)
        if resp.status_code != 200:
            utils.log("Sky free API HTTP %s id=%s" % (resp.status_code, sky_id))
            return None
        data = resp.json()
        stream_url = data.get("streaming_url") or data.get("hls_url") or ""
        if not stream_url:
            utils.log("Sky free id=%s: nessun URL" % sky_id)
            return None
        # I token Akamai durano ~5 minuti: evita di dare un URL gia' scaduto.
        if not _probe_manifest(stream_url, user_agent=utils.SKY_UA, referer=referer,
                               origin="https://video.sky.it"):
            utils.log("Sky free %s: manifest scaduto (probe fallito)" % sky_id)
            return None
        utils.log("Sky free %s: %s" % (sky_id, stream_url[:80]))
        return {
            "url": stream_url,
            "name": utils.SKY_FREE_CHANNELS.get(sky_id, data.get("title") or sky_id),
            "drm": False,
            "user_agent": utils.SKY_UA,
            "referer": referer,
        }
    except Exception as exc:
        utils.log("Errore resolve Sky free %s: %s" % (sky_id, exc))
        return None


# --------------------------------------------------------------------------
# Dispatch
# --------------------------------------------------------------------------

def resolve(identifier, channel=None):
    """Risolve un canale WLTV. identifier = play_ref ("rai:Rai 1") o wltv_id."""
    ref = identifier or ""
    if channel and not ref:
        ref = channel.get("play_ref") or infer_play_ref(channel)
    ref = _unwrap_identifier(ref)
    utils.log("WLTV resolve ref=%s" % ref)

    if ":" not in ref:
        compact = re.sub(r"[^a-z0-9]+", "", ref.lower())
        if compact in RAI_BY_ID:
            return _resolve_rai(RAI_BY_ID[compact])
        if compact in MEDIASET_CALLSIGNS or compact.upper() in MEDIASET_CLR:
            return _resolve_mediaset(ref)
        guessed = infer_play_ref({"wltv_id": ref, "name": ref})
        if guessed and guessed != ref:
            return resolve(guessed, channel)
        return None

    broadcaster, _, search = ref.partition(":")
    broadcaster = (broadcaster or "").lower()
    search = search or ref
    try:
        if broadcaster == "rai":
            return _resolve_rai(search)
        if broadcaster == "mediaset":
            return _resolve_mediaset(search)
        if broadcaster == "la7":
            return _resolve_la7(search)
        if broadcaster == "discovery":
            return _resolve_discovery(search)
        if broadcaster == "sky":
            sky_ids = {"SKYTG24": "1", "CIELO": "2", "TV8": "7"}
            sky_id = sky_ids.get(utils.normalize_name(search))
            if not sky_id:
                return None
            return _resolve_sky_free(sky_id)
    except Exception as exc:
        utils.log("WLTV resolve error (%s): %s" % (ref, exc))
    return None
