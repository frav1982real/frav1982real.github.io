import logging
import base64
import re
import unicodedata

# User-Agent per l'endpoint Heroku dei PPV (Sky)
SKY_UA = "okhttp/4.11.0"

# Canali Sky gratuiti (metodo WLTV: API player video.sky.it)
SKY_FREE_API = "https://video.sky.it/api/v1/getLivestream?id={}"
SKY_FREE_CHANNELS = {
    "1": "Sky TG24",
    "2": "Cielo",
    "7": "TV8",
}
SKY_FREE_REFERER = {
    "1": "https://video.sky.it/",
    "2": "https://www.cielo.it/",
    "7": "https://www.tv8.it/streaming",
}


def log(msg):
    text = "[CANATTV] %s" % msg
    try:
        import xbmc
        xbmc.log(text, xbmc.LOGINFO)
    except Exception:
        try:
            logging.info(text)
        except Exception:
            pass

def _xor_decrypt(data_b64, key):
    data = base64.b64decode(data_b64)
    key_bytes = (key or "").encode()
    if not key_bytes:
        return ""
    out = bytearray()
    for i, byte in enumerate(data):
        out.append(byte ^ key_bytes[i % len(key_bytes)])
    return out.decode("utf-8")


def strip_accents(text):
    try:
        nfkd = unicodedata.normalize("NFKD", text or "")
        return "".join(c for c in nfkd if not unicodedata.combining(c))
    except Exception:
        return text or ""


def normalize_name(name):
    """Normalizza un nome di canale per il confronto (HD ignorato, +1 distinto)."""
    s = strip_accents(name or "").upper().replace("È", "E")
    s = re.sub(r"\s*\+24\s*", "PLUS24", s)
    s = re.sub(r"\s*\+1\s*", "PLUS1", s)
    s = re.sub(r"\s*\.(C|S)\s*$", "", s)
    s = re.sub(r"\[[^\]]*\]", " ", s)
    s = re.sub(r"\([^)]*\)", " ", s)
    s = re.sub(r"\bHD\b", " ", s)
    s = re.sub(r"\b4K\b", " ", s)
    s = re.sub(r"[^A-Z0-9]+", "", s)
    return s
