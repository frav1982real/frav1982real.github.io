# -*- coding: utf-8 -*-
"""Generazione della playlist M3U per il PVR IPTV Simple Client.

Stile World Live TV: TUTTI i canali puntano all'addon via plugin://,
così ogni stream viene risolto al momento della riproduzione (i free
con free.json/resolver dinamico, i PPV con il loro endpoint).

    #EXTINF:-1 tvg-id="skyuno" tvg-chno="108" tvg-name="Sky Uno HD" group-title="...",Sky Uno HD
    plugin://plugin.video.canatv.plus/play/skyuno

tvg-chno = LCN: è così che il PVR mostra la numerazione giusta nella
guida TV, rispettando l'ordine/LCN di canali.json.
"""

ADDON_ID = "plugin.video.canatv.plus"


def build_playlist(channels):
    """Costruisce il testo della playlist M3U a partire dalla lista canali."""
    lines = ["#EXTM3U"]

    for c in channels:
        header = (
            f'#EXTINF:-1 tvg-id="{c["id"]}" '
            f'tvg-chno="{c["lcn"]}" '
            f'tvg-name="{c["name"]}" '
            f'group-title="{c.get("group", "")}",{c["name"]}'
        )
        lines.append(header)
        lines.append(f"plugin://{ADDON_ID}/play/{c['id']}")

    return "\n".join(lines) + "\n"
