# -*- coding: utf-8 -*-
"""Route dell'addon: menu, PVR, sfoglia canali e playback."""

import routing
import xbmcgui
import xbmcaddon
import xbmcplugin

from urllib.parse import quote

from . import channels, playlist, pvr, resolver

plugin = routing.Plugin()
ADDON_NAME = xbmcaddon.Addon().getAddonInfo("name")


# ============================================================================
# MENU PRINCIPALE
# ============================================================================
@plugin.route("/")
def index():
    handle = plugin.handle

    li = xbmcgui.ListItem(label="Aggiorna lista PVR (IPTV Simple Client)")
    xbmcplugin.addDirectoryItem(handle, plugin.url_for(pvrupdate), li, isFolder=False)

    li = xbmcgui.ListItem(label="Sfoglia canali")
    xbmcplugin.addDirectoryItem(handle, plugin.url_for(channels_route), li, isFolder=True)

    xbmcplugin.endOfDirectory(handle, succeeded=True)


# ============================================================================
# INTEGRAZIONE PVR IPTV SIMPLE CLIENT
# ============================================================================
@plugin.route("/pvrupdate")
def pvrupdate():
    # 1. il PVR deve essere installato
    if not pvr.pvr_installed():
        xbmcgui.Dialog().notification(
            ADDON_NAME, "Installa il PVR IPTV Simple Client dal repository",
            xbmcgui.NOTIFICATION_ERROR, 8000)
        return

    # 2. genera la playlist dal JSON (LCN rispettati: tvg-chno)
    canali = channels.get_channels()
    content = playlist.build_playlist(canali)

    # 3. scrivi il file e punta il PVR
    path = pvr.write_playlist(content)
    pvr.set_pvr_settings(path)

    # 4. ricarica il PVR (disattiva -> pulisci cache -> riattiva)
    pvr.reload_pvr()

    xbmcgui.Dialog().notification(
        ADDON_NAME, "Lista aggiornata: %d canali" % len(canali), 5000)


# ============================================================================
# SFOGLIA CANALI (stesso contenuto della lista PVR)
# ============================================================================
@plugin.route("/channels")
def channels_route():
    handle = plugin.handle

    for c in channels.get_channels():
        li = xbmcgui.ListItem(label="[%d] %s" % (c["lcn"], c["name"]))
        li.setInfo("video", {"title": c["name"]})
        li.setProperty("IsPlayable", "true")
        url = plugin.url_for(play, c["id"])
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True)


# ============================================================================
# RIPRODUZIONE — resolving sul momento (free stile WLT, PPV endpoint dedicato)
# ============================================================================
@plugin.route("/play/<channel_id>")
def play(channel_id):
    handle = plugin.handle

    ch = channels.get_channel(channel_id)
    if ch is None:
        _resolve_failed("Canale sconosciuto: %s" % channel_id)
        return

    result = resolver.resolve(ch)
    if not result or not result.get("url"):
        _resolve_failed("Link non disponibile per %s" % ch["name"])
        return

    li = xbmcgui.ListItem(path=_final_url(result))
    li.setInfo("video", {"title": ch["name"]})

    # DRM (ClearKey degli Sky PPV) -> inputstream.adaptive
    if result.get("drm"):
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setProperty("inputstream.adaptive.license_type",
                       result.get("drm_type", ""))
        li.setProperty("inputstream.adaptive.license_key",
                       result.get("drm_key", ""))

    xbmcplugin.setResolvedUrl(handle, True, li)


def _final_url(result):
    """Appende User-Agent/Referer/Origin all'URL (pipe-syntax Kodi)."""
    url = (result.get("url") or "").strip()
    parts = []
    if result.get("user_agent"):
        parts.append("User-Agent=" + quote(result["user_agent"], safe=""))
    if result.get("referer"):
        parts.append("Referer=" + quote(result["referer"], safe=""))
    if result.get("origin"):
        parts.append("Origin=" + quote(result["origin"], safe=""))
    if parts and "|" not in url:
        url += "|" + "&".join(parts)
    return url


def _resolve_failed(msg):
    xbmcgui.Dialog().notification(ADDON_NAME, msg,
                                  xbmcgui.NOTIFICATION_ERROR, 8000)
    xbmcplugin.setResolvedUrl(plugin.handle, False, xbmcgui.ListItem())


def run():
    plugin.run()
