# -*- coding: utf-8 -*-
"""Caricamento canali da resources/data/canali.json.

canali.json contiene la lista dei canali (lcn, name, id) nell'ordine
ufficiale: quell'ordine viene PRESERVATO ed è ciò che guida sia la
guida TV (tvg-chno = lcn) sia la lista dentro l'addon.

Ogni canale viene arricchito a runtime con:

    type  = "free" se l'id ha un link non vuoto in free.json,
            "ppv" altrimenti (risolto al click)
    group = sezione della guida TV (in base all'LCN)
    url   = link statico per i canali free ("" se assente)
"""

import json
import os

from xbmcaddon import Addon

DATA_DIR = os.path.join(Addon().getAddonInfo("path"), "resources", "data")
CANALI_JSON = os.path.join(DATA_DIR, "canali.json")
FREE_JSON = os.path.join(DATA_DIR, "free.json")

_cache = None


def group_for_lcn(lcn):
    """Sezione (gruppo guida TV) in base all'LCN."""
    if lcn < 200:
        return "Intrattenimento e Serie TV"
    if lcn < 249:
        return "Sport"
    if lcn < 300:
        return "Calcio"
    if lcn < 400:
        return "Cinema"
    if lcn < 600:
        return "News"
    if lcn < 700:
        return "Bambini"
    if lcn < 800:
        return "Primafila"
    if lcn >= 1000:
        return "Regionali"
    return "Canali"


def _load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def get_channels(force=False):
    """Lista canali arricchiti, cacheata; ordine = quello di canali.json."""
    global _cache
    if _cache is None or force:
        raw = _load_json(CANALI_JSON).get("channels", [])
        free = _load_json(FREE_JSON)

        _cache = []
        for c in raw:
            cid = c["id"]
            url = (free.get(cid) or "").strip()
            _cache.append({
                "lcn": c["lcn"],
                "name": c["name"],
                "id": cid,
                "type": "free" if url else "ppv",
                "group": group_for_lcn(c["lcn"]),
                "url": url,
            })
    return _cache


def get_channel(channel_id):
    """Cerca un canale per id. Ritorna il dict o None."""
    for c in get_channels():
        if c["id"] == channel_id:
            return c
    return None
