# -*- coding: utf-8 -*-
"""Integrazione con il PVR IPTV Simple Client.

  1. l'addon GENERA la playlist M3U (lib/playlist.py) e la scrive nella
     sua cartella dati (special://profile/addon_data/...)
  2. imposta pvr.iptvsimple perché legga quel file:
        m3uPathType = "0"   (0 = file locale)
        m3uPath     = <percorso del file>
  3. ricarica il PVR: disattiva via JSON-RPC, pulisce la cache
     (iptv.m3u.cache*, xmltv.xml.cache*), riattiva.
"""

import json
import os

import xbmc
import xbmcaddon
from xbmcvfs import translatePath

PVR_ID = "pvr.iptvsimple"
PLAYLIST_NAME = "playlist.m3u"


def playlist_path():
    """Percorso del file playlist dentro la cartella dati dell'addon."""
    profile = translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    if not os.path.isdir(profile):
        os.makedirs(profile)
    return os.path.join(profile, PLAYLIST_NAME)


def pvr_installed():
    """True se pvr.iptvsimple è installato (e abilitato) in Kodi."""
    return xbmc.getCondVisibility(f"System.HasAddon({PVR_ID})")


def write_playlist(content):
    """Scrive la playlist sul disco, ritorna il percorso completo."""
    path = playlist_path()
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


def set_pvr_settings(path):
    """Punta il PVR al file playlist locale."""
    pvr = xbmcaddon.Addon(PVR_ID)
    pvr.setSetting("m3uPathType", "0")      # 0 = file locale
    pvr.setSetting("m3uPath", path)
    pvr.setSetting("epgPathType", "0")      # EPG per ora disabilitato
    pvr.setSetting("epgPath", "")


def reload_pvr():
    """Disattiva -> pulisce la cache -> riattiva il PVR (forza il reload)."""
    _set_enabled(False)
    xbmc.sleep(1500)
    _cleanup_cache()
    _set_enabled(True)


def _set_enabled(enabled):
    request = {
        "jsonrpc": "2.0",
        "method": "Addons.SetAddonEnabled",
        "params": {"addonid": PVR_ID, "enabled": enabled},
        "id": 1,
    }
    xbmc.executeJSONRPC(json.dumps(request))


def _cleanup_cache():
    """Elimina i file di cache del PVR (iptv.m3u.cache*, xmltv.xml.cache*)."""
    profile = translatePath(xbmcaddon.Addon(PVR_ID).getAddonInfo("profile"))
    if not os.path.isdir(profile):
        return
    for name in os.listdir(profile):
        if name.startswith("iptv.m3u.cache") or name.startswith("xmltv.xml.cache"):
            try:
                os.remove(os.path.join(profile, name))
            except OSError:
                pass
