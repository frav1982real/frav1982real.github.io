# -*- coding: utf-8 -*-
"""Risoluzione dei canali al momento della riproduzione.

  - FREE: metodo WorldLiveTV (resources/lib/wltv.py): broadcaster
    ufficiale per editore (RAI, Mediaset, La7, Discovery/WBD, Sky free);
    fallback sul link statico di free.json; infine fallback Vavoo.
  - PPV: endpoint Heroku -> decifratura XOR -> controllo scadenza ->
    fallback Vavoo se il link è scaduto o assente.
"""

import json
import re
import time
import uuid
from datetime import datetime

import requests

from . import free as free_resolver
from . import utils

HEROKU_ENDPOINT = "https://test34344.herokuapp.com/filter.php?numTest=A1A159&id={id}"
SKY_SECRET = "my_secret_key"

VYPN_PING_URL = "https://www.vypn.net/api/app/ping"
VAVOO_PING2_URL = "https://www.vavoo.tv/api/box/ping2"
VAVOO_CATALOG_URL = "https://vavoo.to/mediahubmx-catalog.json"
VAVOO_RESOLVE_URL = "https://vavoo.to/mediahubmx-resolve.json"

UA_PING = "electron-fetch/1.0 electron (+https://github.com/arantes555/electron-fetch)"
UA_API = "okhttp/4.11.0"
UA_RESOLVE = "MediaHubMX/2"
CLIENT_VERSION = "3.1.0"

VEC_DATA = {"vec": "9frjpxPjxSNilxJPCJ0XGYs6scej3dW/h/VWlnKUiLSG8IP7mfyDU7NirOlld+VtCKGj03XjetfliDMhIev7wcARo+YTU8KPFuVQP9E2DVXzY2BFo1NhE6qEmPfNDnm74eyl/7iFJ0EETm6XbYyz8IKBkAqPN/Spp3PZ2ulKg3QBSDxcVN4R5zRn7OsgLJ2CNTuWkd/h451lDCp+TtTuvnAEhcQckdsydFhTZCK5IiWrrTIC/d4qDXEd+GtOP4hPdoIuCaNzYfX3lLCwFENC6RZoTBYLrcKVVgbqyQZ7DnLqfLqvf3z0FVUWx9H21liGFpByzdnoxyFkue3NzrFtkRL37xkx9ITucepSYKzUVEfyBh+/3mtzKY26VIRkJFkpf8KVcCRNrTRQn47Wuq4gC7sSwT7eHCAydKSACcUMMdpPSvbvfOmIqeBNA83osX8FPFYUMZsjvYNEE3arbFiGsQlggBKgg1V3oN+5ni3Vjc5InHg/xv476LHDFnNdAJx448ph3DoAiJjr2g4ZTNynfSxdzA68qSuJY8UjyzgDjG0RIMv2h7DlQNjkAXv4k1BrPpfOiOqH67yIarNmkPIwrIV+W9TTV/yRyE1LEgOr4DK8uW2AUtHOPA2gn6P5sgFyi68w55MZBPepddfYTQ+E1N6R/hWnMYPt/i0xSUeMPekX47iucfpFBEv9Uh9zdGiEB+0P3LVMP+q+pbBU4o1NkKyY1V8wH1Wilr0a+q87kEnQ1LWYMMBhaP9yFseGSbYwdeLsX9uR1uPaN+u4woO2g8sw9Y5ze5XMgOVpFCZaut02I5k0U4WPyN5adQjG8sAzxsI3KsV04DEVymj224iqg2Lzz53Xz9yEy+7/85ILQpJ6llCyqpHLFyHq/kJxYPhDUF755WaHJEaFRPxUqbparNX+mCE9Xzy7Q/KTgAPiRS41FHXXv+7XSPp4cy9jli0BVnYf13Xsp28OGs/D8Nl3NgEn3/eUcMN80JRdsOrV62fnBVMBNf36+LbISdvsFAFr0xyuPGmlIETcFyxJkrGZnhHAxwzsvZ+Uwf8lffBfZFPRrNv+tgeeLpatVcHLHZGeTgWWml6tIHwWUqv2TVJeMkAEL5PPS4Gtbscau5HM+FEjtGS+KClfX1CNKvgYJl7mLDEf5ZYQv5kHaoQ6RcPaR6vUNn02zpq5/X3EPIgUKF0r/0ctmoT84B2J1BKfCbctdFY9br7JSJ6DvUxyde68jB+Il6qNcQwTFj4cNErk4x719Y42NoAnnQYC2/qfL/gAhJl8TKMvBt3Bno+va8ve8E0z8yEuMLUqe8OXLce6nCa+L5LYK1aBdb60BYbMeWk1qmG6Nk9OnYLhzDyrd9iHDd7X95OM6X5wiMVZRn5ebw4askTTc50xmrg4eic2U1w1JpSEjdH/u/hXrWKSMWAxaj34uQnMuWxPZEXoVxzGyuUbroXRfkhzpqmqqqOcypjsWPdq5BOUGL/Riwjm6yMI0x9kbO8+VoQ6RYfjAbxNriZ1cQ+AW1fqEgnRWXmjt4Z1M0ygUBi8w71bDML1YG6UHeC2cJ2CCCxSrfycKQhpSdI1QIuwd2eyIpd4LgwrMiY3xNWreAF+qobNxvE7ypKTISNrz0iYIhU0aKNlcGwYd0FXIRfKVBzSBe4MRK2pGLDNO6ytoHxvJweZ8h1XG8RWc4aB5gTnB7Tjiqym4b64lRdj1DPHJnzD4aqRixpXhzYzWVDN2kONCR5i2quYbnVFN4sSfLiKeOwKX4JdmzpYixNZXjLkG14seS6KR0Wl8Itp5IMIWFpnNokjRH76RYRZAcx0jP0V5/GfNNTi5QsEU98en0SiXHQGXnROiHpRUDXTl8FmJORjwXc0AjrEMuQ2FDJDmAIlKUSLhjbIiKw3iaqp5TVyXuz0ZMYBhnqhcwqULqtFSuIKpaW8FgF8QJfP2frADf4kKZG1bQ99MrRrb2A="}


def resolve(channel):
    """Ritorna il dict di riproduzione per un canale, o None."""
    if not channel:
        return None

    # 1) canali FREE: metodo WorldLiveTV (broadcaster ufficiali per
    #    editore; fallback sul link statico di free.json)
    url = free_resolver.resolve_free(channel)
    if url:
        return {"url": url, "drm": False}

    # 2) canali PPV: endpoint dedicato -> scadenza -> fallback Vavoo
    if channel.get("type") == "ppv":
        return resolve_ppv(channel)

    # 3) free non risolto -> fallback Vavoo
    return _resolve_vavoo_fallback(channel)


def resolve_ppv(channel):
    """Risoluzione PPV.

      1. prende l'id dalla lista canali
      2. lo inserisce nell'endpoint Heroku
      3. fa il resolving e ottiene ciò che serve (manifest/kid/key/scadenza)
      4. se il link è scaduto (unix timestamp superato) -> fallback Vavoo
    """
    channel_id = channel.get("id") if isinstance(channel, dict) else channel
    result = _resolve_sky_ppv(channel_id)
    if result:
        return result

    # Link scaduto o non disponibile -> fallback Vavoo
    return _resolve_vavoo_fallback(channel)


def _resolve_sky_ppv(channel_id):
    """Risolve via endpoint Heroku; None se scaduto/assente (scatta il fallback)."""
    if not channel_id:
        return None

    api_url = HEROKU_ENDPOINT.format(id=channel_id)
    utils.log("Resolving Sky PPV: %s" % channel_id)
    try:
        resp = requests.get(api_url, headers={"User-Agent": utils.SKY_UA}, timeout=30)
        if resp.status_code != 200:
            utils.log("Sky PPV API HTTP %d" % resp.status_code)
            return None

        encrypted = (resp.json() or {}).get("data") or ""
        if not encrypted:
            utils.log("Sky PPV: nessun payload per %s" % channel_id)
            return None

        data = json.loads(utils._xor_decrypt(encrypted, SKY_SECRET))
        manifest = data.get("manifest") or ""
        if not manifest:
            utils.log("Sky PPV: manifest mancante per %s" % channel_id)
            return None

        # Scadenza: unix timestamp (secondi o millisecondi).
        expiry = _parse_expiry(data)
        if expiry is not None and time.time() > expiry:
            utils.log("Sky PPV link scaduto (ts=%s) -> fallback Vavoo" % expiry)
            return None

        result = {"url": manifest, "name": channel_id, "drm": False}

        kid = data.get("kid") or ""
        key = data.get("key") or ""
        if kid and key:
            result.update({
                "drm": True,
                "drm_type": "org.w3.clearkey",
                "drm_key": "%s:%s" % (kid, key),
            })
        return result

    except Exception as exc:
        utils.log("Errore resolve Sky PPV %s: %s" % (channel_id, exc))
        return None


def _parse_expiry(data):
    """Unix timestamp (secondi o ms) o data "%d/%m/%Y %H:%M:%S"; None se assente."""
    for key in ("fine", "exp", "expiry", "expire", "expires", "ts", "timestamp"):
        val = data.get(key)
        if val in (None, ""):
            continue
        if isinstance(val, str) and "EXPIRE" in val.upper():
            continue
        try:
            ts = float(val)
        except (TypeError, ValueError):
            ts = _parse_expiry_datetime(str(val))
            if ts is None:
                continue
            return ts
        if ts > 1e12:
            ts = ts / 1000.0
        return ts
    return None


def _parse_expiry_datetime(text):
    for fmt in ("%d/%m/%Y %H:%M:%S", "%Y-%m-%d %H:%M:%S", "%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).timestamp()
        except ValueError:
            continue
    return None


def _resolve_vavoo_fallback(channel):
    """Fallback: risolve il canale tramite Vavoo (catalogo Italy + resolve)."""
    try:
        client = VavooClient()
        link = _find_vavoo_link(client, channel)
        if not link:
            utils.log("Vavoo: nessun match nel catalogo per %s" % _channel_name(channel))
            return None
        url, mode = client.resolve_with_fallback(link)
        if not url:
            return None
        utils.log("Vavoo fallback ok (%s) per %s" % (mode, _channel_name(channel)))
        return {"url": url, "drm": False}
    except Exception as exc:
        utils.log("Errore fallback Vavoo: %s" % exc)
        return None


def _find_vavoo_link(client, channel):
    """Cerca il link Vavoo del canale nel catalogo (match per nome)."""
    name = _channel_name(channel)
    if not name:
        return None
    try:
        items = client.get_channels(group="Italy")
    except Exception as exc:
        utils.log("Vavoo: errore catalogo: %s" % exc)
        return None

    target = _normalize(name)
    for item in items or []:
        link = item.get("link") or item.get("url")
        if not link:
            continue
        for key in ("name", "title", "displayName", "display_name"):
            cand = item.get(key)
            if cand and _normalize(cand) == target:
                return link

    # match parziale (es. "Sky Uno HD" dentro "Sky Uno HD FHD")
    for item in items or []:
        link = item.get("link") or item.get("url")
        if not link:
            continue
        for key in ("name", "title", "displayName", "display_name"):
            cand = item.get(key)
            norm = _normalize(cand)
            if norm and (target in norm or norm in target):
                return link
    return None


def _normalize(text):
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def _channel_name(channel):
    if isinstance(channel, dict):
        return channel.get("name") or channel.get("id") or ""
    return str(channel)


# --------------------------------------------------------------------------
# Client Vavoo (invariato rispetto alla versione precedente)
# --------------------------------------------------------------------------

def vypn_ping_data():
    """Payload del ping alla piattaforma VYPN (identità net.vypn.app)."""
    now_ms = int(time.time() * 1000)
    return {
        "token": "",
        "reason": "app-focus",
        "locale": "de",
        "theme": "dark",
        "metadata": {
            "device": {"type": "phone", "uniqueId": uuid.uuid4().hex[:16]},
            "os": {"name": "android", "version": "14", "abis": ["arm64-v8a"], "host": "android"},
            "app": {"platform": "android"},
            "version": {"package": "net.vypn.app", "binary": "1.4.1", "js": "1.4.1"},
        },
        "appFocusTime": 0,
        "playerActive": False,
        "playDuration": 0,
        "devMode": False,
        "hasAddon": True,
        "castConnected": False,
        "package": "net.vypn.app",
        "version": "1.4.1",
        "process": "app",
        "firstAppStart": now_ms - 86400000,
        "lastAppStart": now_ms,
        "ipLocation": None,
        "adblockEnabled": True,
        "migrationApplied": False,
        "migrationTargetInstalled": False,
        "proxy": {
            "supported": ["ss"],
            "engine": "Mu",
            "ssVersion": "2022",
            "enabled": False,
            "autoServer": True,
            "id": "",
        },
        "iap": {"supported": False, "error": ""},
    }


class VavooClient(object):
    """Client vavoo.to.

    La firma (addonSig) viene rifatta fresca a ogni riproduzione:
    riutilizzare una firma vecchia fa servire promo "VYPN" al posto
    del canale.
    """

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": UA_RESOLVE})
        self._signature = None
        self._signature_ts = 0

    # ------------------------------------------------------------------ ping
    def get_auth_signature(self, force=False):
        """addonSig dal ping (prima vypn.net, poi vavoo.tv come fallback)."""
        signature = self._ping(VYPN_PING_URL, vypn_ping_data(), UA_PING)
        if not signature:
            utils.log("Ping vypn.net fallito")
            return None
        self._signature = signature
        self._signature_ts = time.time()
        return signature

    def _ping(self, url, data, user_agent):
        headers = {
            "user-agent": user_agent,
            "accept": "application/json",
            "content-type": "application/json; charset=utf-8",
            "accept-encoding": "gzip",
            "Accept-Language": "de",
        }
        try:
            resp = self.session.post(url, json=data, headers=headers, timeout=30)
            resp.raise_for_status()
            return resp.json().get("addonSig")
        except Exception as exc:
            utils.log("Errore ping %s: %s" % (url, exc))
            return None

    def get_ts_signature(self):
        """Firma per i flussi .ts (streammode=0)."""
        try:
            req = self.session.post(VAVOO_PING2_URL, data=VEC_DATA, timeout=30)
            return req.json()["response"].get("signed")
        except Exception as exc:
            utils.log("Errore ping2 vavoo: %s" % exc)
            return None

    # --------------------------------------------------------------- catalogo
    def get_channels(self, group="Italy", progress_callback=None):
        """Scarica l'intero catalogo di un gruppo."""
        signature = self.get_auth_signature()
        headers = {
            "user-agent": UA_API,
            "accept": "application/json",
            "content-type": "application/json; charset=utf-8",
            "accept-encoding": "gzip",
            "mediahubmx-signature": signature or "",
        }
        all_channels = []
        cursor = 0
        while True:
            data = {
                "language": "de",
                "region": "AT",
                "catalogId": "iptv",
                "id": "iptv",
                "adult": False,
                "search": "",
                "sort": "name",
                "filter": {"group": group},
                "cursor": cursor,
                "clientVersion": CLIENT_VERSION,
            }
            resp = self.session.post(VAVOO_CATALOG_URL, json=data, headers=headers, timeout=30)
            resp.raise_for_status()
            result = resp.json()
            items = result.get("items", [])
            all_channels.extend(items)
            if progress_callback:
                progress_callback(len(all_channels))
            cursor = result.get("nextCursor")
            if not cursor:
                break

        return all_channels

    # --------------------------------------------------------------- resolve
    def resolve_link(self, link, streammode=1):
        """Risolve l'url di un canale."""
        if not link:
            return None
        if streammode == 1:
            signature = self.get_auth_signature()
            if not signature:
                return self.resolve_link(link, streammode=0)
            headers = {
                "user-agent": UA_RESOLVE,
                "accept": "application/json",
                "content-type": "application/json; charset=utf-8",
                "accept-encoding": "gzip",
                "mediahubmx-signature": signature,
            }
            data = {"language": "de", "region": "AT", "url": link, "clientVersion": CLIENT_VERSION}
            try:
                resp = self.session.post(VAVOO_RESOLVE_URL, json=data, headers=headers, timeout=30)
                resp.raise_for_status()
                result = resp.json()
                if isinstance(result, list) and result and result[0].get("url"):
                    return result[0]["url"]
                if isinstance(result, dict) and result.get("url"):
                    return result["url"]
                return None
            except Exception as exc:
                utils.log("Errore resolve vavoo: %s" % exc)
                return None
        else:
            try:
                ts_signature = self.get_ts_signature()
                if not ts_signature:
                    return None
                ts_url = "%s.ts?n=1&b=5&vavoo_auth=%s" % (
                    link.replace("vavoo-iptv", "live2")[0:-12],
                    ts_signature,
                )
                return ts_url
            except Exception as exc:
                utils.log("Errore resolve ts vavoo: %s" % exc)
                return None

    def resolve_with_fallback(self, link):
        """Prima streammode=1; poi firma nuova; infine streammode=0 (.ts)."""
        resolved = self.resolve_link(link, streammode=1)
        if resolved:
            return resolved, "principale"

        self.get_auth_signature(force=True)
        resolved = self.resolve_link(link, streammode=1)
        if resolved:
            return resolved, "principale"

        resolved = self.resolve_link(link, streammode=0)
        if resolved:
            return resolved, "fallback"
        return None, None
