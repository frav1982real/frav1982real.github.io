# -*- coding: utf-8 -*-
"""Risoluzione dei canali FREE con il metodo WorldLiveTV.

Ogni canale free viene risolto AL MOMENTO della riproduzione tramite
un "broadcaster" per editore (vedi resources/lib/wltv.py):

  1. se il canale appartiene a un broadcaster noto (RAI, Mediaset, La7,
     Discovery/WBD, Sky free) lo stream ufficiale viene risolto al volo
     (dirette.json, flussi clear Mediaset, API Aurora, API Sky);
  2. altrimenti si usa il link statico di free.json;
  3. se anche quello manca, resolver.py passa al fallback Vavoo.
"""

from . import utils
from . import wltv


def resolve_free(channel):
    """Ritorna l'URL del canale free, o None se non risolvibile."""
    if not channel:
        return None

    # 1) metodo WorldLiveTV: broadcaster ufficiale per editore
    ref = wltv.infer_play_ref(channel)
    if ref:
        utils.log("Free via WLTV: %s (%s)" % (channel.get("name"), ref))
        result = wltv.resolve(ref, channel)
        if result and result.get("url"):
            return result["url"]
        utils.log("WLTV senza stream per %s: provo il link statico" % channel.get("name"))

    # 2) link statico (free.json)
    return (channel.get("url") or "").strip() or None


def is_rai(name):
    """True se il nome corrisponde a un canale Rai (usato dal resolver)."""
    return (utils.normalize_name(name) or "").startswith("RAI")


# Alias retrocompatibilita'
_is_rai = is_rai
