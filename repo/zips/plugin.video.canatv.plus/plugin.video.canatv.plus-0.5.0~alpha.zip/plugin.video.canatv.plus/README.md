# CanàTV Plus (Kodi / Omega)

Addon video per Kodi 21 Omega: **PVR IPTV Simple Client** + canali free + PPV.

## Architettura

- `default.py` — entrypoint minimale (guida ufficiale Kodi)
- `resources/lib/router.py` — routing (`/`, `/channels`, `/play/<id>`, `/pvrupdate`)
- `resources/lib/channels.py` — carica `canali.json`: ordine/LCN PRESERVATI
- `resources/lib/free.py` — canali free con il metodo **WorldLiveTV**:
  broadcaster per editore (RAI, Mediaset, La7, Discovery/WBD, Sky free)
  che risolve lo stream ufficiale al volo; fallback sul link statico di
  `free.json`
- `resources/lib/wltv.py` — metodo di resolving WorldLiveTV: un
  "broadcaster" per editore con probe del manifest prima della riproduzione
- `resources/lib/playlist.py` — playlist M3U stile World Live TV: tutti i
  canali puntano a `plugin://plugin.video.canatv.plus/play/<id>`, quindi
  ogni stream viene risolto al momento della riproduzione; `tvg-chno` = LCN
- `resources/lib/pvr.py` — integrazione PVR IPTV Simple Client: scrittura
  playlist, impostazioni del PVR e reload con pulizia cache

## Uso

1. Installa il PVR **IPTV Simple Client** dal repository Kodi.
2. Apri l'addon → *Aggiorna lista PVR*: genera la playlist e configura il PVR.
   I canali compaiono nella sezione TV con la numerazione LCN corretta.
3. *Sfoglia canali* permette di provare i canali dentro l'addon, senza PVR.

## Verifica

```
pip install kodi-addon-checker
kodi-addon-checker --branch omega
```

## Dati

- `canali.json` — lista ufficiale dei canali (lcn, name, id); l'ordine è quello
  mostrato in guida TV. Non rimuovere i doppioni: sono voluti.
- `free.json` — link statici dei canali free, mappati per id.
