# plugin.video.canatv.plus

Addon Kodi (Omega 21+) per CanàTV: PVR IPTV Simple Client + PPV + canali free (LCN dal JSON).

## Requisiti

- Kodi 21 Omega o superiore
- Dipendenze installate automaticamente dal repository ufficiale:
  `script.module.routing`, `script.module.requests`

## Installazione (da ZIP)

Lo ZIP deve contenere una cartella principale chiamata esattamente
`plugin.video.canatv.plus` — la creazione e la pubblicazione dello ZIP
installabile sono gestite nel repository Kodi dedicato.

Poi in Kodi: *Add-on → Installa da un file zip*.

## Sviluppo

- `default.py` — entrypoint minimale (raccomandato dalle linee guida Kodi)
- `resources/lib/router.py` — route (menu, PVR update, sfoglia, playback) via `script.module.routing`
- `resources/lib/channels.py` — caricamento canali da `resources/data/canali.json`
- `resources/lib/playlist.py` — generazione playlist M3U (LCN = `tvg-chno`)
- `resources/lib/pvr.py` — integrazione con PVR IPTV Simple Client
- `resources/lib/resolver.py` — risoluzione PPV (Sky + fallback Vavoo)

### Verifica

```sh
pip install kodi-addon-checker
kodi-addon-checker --branch omega .
```
