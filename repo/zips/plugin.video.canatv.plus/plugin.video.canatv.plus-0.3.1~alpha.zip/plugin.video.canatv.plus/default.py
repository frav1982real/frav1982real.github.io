# -*- coding: utf-8 -*-
"""Entrypoint di plugin.video.canatv.plus.

La logica (menu, PVR, sfoglia canali, playback) è in resources/lib/router.py.
L'entrypoint resta minimale, come raccomandato dalla documentazione Kodi.
"""

from resources.lib import router


if __name__ == "__main__":
    router.run()
